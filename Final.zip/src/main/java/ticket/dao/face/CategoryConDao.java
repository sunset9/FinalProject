package ticket.dao.face;

public interface CategoryConDao {

	
}
