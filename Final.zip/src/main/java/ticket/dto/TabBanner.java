package ticket.dto;

import java.util.Date;

public class TabBanner {

	private int tabIdx;
	private int pfmIdx;
	private String bannerPath;
	private Date craeteDate;
}
