package ticket.dto;

import java.util.Date;

public class CategoryMu {
	private int cateMuIdx;
	private int pfmInx;
	private Date createDate;

}
