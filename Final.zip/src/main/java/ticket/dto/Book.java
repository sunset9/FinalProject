package ticket.dto;

import java.util.Date;

public class Book {
	private int bookIdx;
	private int pfmIdx;
	private int userIdx;
	private int bookCateIdx;
	private int seatIdx;
	private Date createDate;
}
