package ticket.dao.face;

public interface CategoryFamDao {

}
