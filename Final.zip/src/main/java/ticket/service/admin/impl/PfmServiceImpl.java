package ticket.service.admin.impl;

import org.springframework.stereotype.Service;

import ticket.service.admin.face.PfmService;

@Service
public class PfmServiceImpl implements PfmService{

}
