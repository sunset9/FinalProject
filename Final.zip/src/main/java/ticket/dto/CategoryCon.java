package ticket.dto;

import java.util.Date;

public class CategoryCon {
	private int cateConIdx;
	private int pfmInx;
	private Date createDate;

}
