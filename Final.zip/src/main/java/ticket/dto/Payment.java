package ticket.dto;

import java.util.Date;

public class Payment {
	private int payIdx;
	private String impUid;
	private String merchantUid;
	private String payMethod;
	private int pfmIdx;
	private int paidAmount;
	private String buyerName;
	private int userIdx;
	private String cardAuth;
	private Date createDate;

}
