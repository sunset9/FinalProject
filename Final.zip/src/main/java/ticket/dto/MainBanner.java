package ticket.dto;

import java.util.Date;

public class MainBanner {

	private int mainbanIdx;
	private int pfmIdx;
	private String bannerImgOri;
	private String bannerImgStr;
	private String thumbImgOri;
	private String thumbImgStr;
	private Date createDate;
}
