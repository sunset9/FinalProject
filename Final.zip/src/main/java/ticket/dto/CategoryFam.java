package ticket.dto;

import java.util.Date;

public class CategoryFam {
	private int cateFamIdx;
	private int pfmInx;
	private Date createDate;

}
