package ticket.dto;

import java.util.Date;

public class Performance {
	 private int pfmIdx;
	 private String name;
	 private int genreIdx;
	 private Date start;
	 private Date end;
	 private Date ticketStart;
	 private Date ticketEnd;
	 private int hallIdx;
	 private int ageGradeIdx;
	 private int runningTime;
	 private Date createDate;
	 
}
