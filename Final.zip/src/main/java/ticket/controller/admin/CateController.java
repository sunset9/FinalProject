package ticket.controller.admin;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class CateController {
	/**
	 * @Method설명: 뮤지컬 배너를 불러온다 
	 * @작성자 :박주희
	 */
	@RequestMapping(value="/admin/banner",method=RequestMethod.GET)
	public String loadbanner(Model model) {
		return null;
	}
	//public void 
}
